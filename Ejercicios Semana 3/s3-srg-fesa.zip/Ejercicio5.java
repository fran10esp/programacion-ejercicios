
public class Ejercicio5 {

	public static void main(String arg[]) {
		//Primero declaramos las variables...
/*		short c =32770;
		int a=2147483649;
		byte b=129;
		long e=9223720368547754830L;
		float f=9999999999999999999999999999999999999999999F;
		double g= 9999999999999999999999999999999999999999999999999999999999999999999;
		//...y despu�s las imprimimos por pantalla
		System.out.println(c);
		System.out.println(a);
		System.out.println(b);
		System.out.println(f);
		System.out.println(g);
		System.out.println(e);
		Como hemos dado valores por encima de los rangos, el programa da error
		*/
		
		
	}
}
