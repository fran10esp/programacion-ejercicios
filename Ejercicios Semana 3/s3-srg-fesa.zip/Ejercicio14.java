
public class Ejercicio14 {

	public static void main(String arg[]) {
		
		//int a=399999999*99999999999;
		//System.out.println(a);
		//Si, es posible, da error
		//float b= 454454587*999889999999999999;
		//System.out.println(b);
		//Da error porque 
	}
}
