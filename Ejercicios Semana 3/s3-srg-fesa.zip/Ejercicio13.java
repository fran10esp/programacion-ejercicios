
public class Ejercicio13 {

	public static void main(String arg[]) {
		int a=5,b=0,c;
		c= a/b;
		System.out.println(c);
		// No se puede dividir ning�n n�mero entre 0, no influye el tipo de variable
	}
}
