
public class Ejercicio11 {
	
	public static void main(String arg[]) {
		
		int a,b;
		int c,d;
		a=2;
		b=3*3;
		c=7/3;
		d=a+b*c;
		System.out.println(d);
		/* El resultado no ser� exacto porque la variable c dar� como resultado un decimal,
		y como estamos trabajando con la variable int, esta eliminar� los decimales*/
				
		
	}
}
