
public class Ejercicio6 {

	public static void main(String arg[]) {
		
		float a=1234567890.0F;
		float b=1234567899.0F;
		System.out.println(a - b); //El resultado es 0.0 porque los valores se pasan de los rangos
	}
}
