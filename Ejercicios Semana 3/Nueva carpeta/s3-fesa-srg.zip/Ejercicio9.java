
public class Ejercicio9 {
	
	public static void main(String arg[]) {
		
		//char a='Hola';//El programa da error porque las variables char solo pueden contener un caracter.
		String b="Hola"	;//En cambio, la variable String permite contener cadenas de texto.	
	}

}
