
public class Ejercicio8 {
	
	public static void main(String arg[]) {
		
		int a;
		//int a;//El sistema da error porque inicialmente ya hab�amos declarado la variale a.
		int b;
		//float b;//El sistema tambi�n dar� error si declaramos una variable con un tipo distinto
	}
}
