
public class Ejercicio2 {
	
	public static void main(String arg[]) {
		
		int a;
		//System.out.println(a); //El programa da error porque no le hemos dado valor a la variable
		//int b=a; //Como la variable a no ha sido inicializada, por lo tanto la variable b tampoco
	}
}
