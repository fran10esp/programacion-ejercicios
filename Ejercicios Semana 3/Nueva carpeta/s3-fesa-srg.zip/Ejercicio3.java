
public class Ejercicio3 {

	public static void main(String arg[]) {
		
		int a=3;
		a=4;
		System.out.println(a);
		//se puede cambiar el valor de una variable, sin importar el tipo de variable
	}
}
