
public class Ejercicio1 {
	
		public static void main(String arg[]) {
			
			short a=3;
			int b=12345;
			byte c=5;
			char d='a';
			long e=56;
			float f=3.38F;
			double g=543;
			boolean h=false;
			String i="Hola Mundo";
			System.out.println(a);
			System.out.println(b);
			System.out.println(c);
			System.out.println(d);
			System.out.println(e);
			System.out.println(f);
			System.out.println(g);
			System.out.println(h);
			System.out.println(i);
		}
	
}
