
public class Ejercicio7 {
	
	public static void main(String arg[]) {
		
		int a,b,c;
		a=5;
		b=7;
		c=9;
		int d=7,h,i=8;
		h=1;
	
		
	}
}
