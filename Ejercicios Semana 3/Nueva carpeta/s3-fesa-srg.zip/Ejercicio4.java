
public class Ejercicio4 {

	public static void main(String arg[]) {
		
		final int a =3;
		//a=4; //No se puede cambiar el valor de una constante, porque su valor es definitivo una vez asignado
		final int b;
		b=5;// Si es posible, si al declarar la constante no le damos ning�n valor
		//b=6;//No se puede cambiar el valor porque ya le hab�amos asignado un valor a la constante
	}
}
