
public class Ejercicio3 {
	
	public static void main(String args []) {
		
		byte c=5;
		short ca=c;//SI
		int cb=c;//SI
		long cc=c;//SI
		float cd=c;//SI
		double ce=c;//SI
		char cf=(char)c;//SI
		boolean cg=(boolean)c;//NO
		String ch=(String)c;//NO
		
		
		short a=2;
		byte aa=(byte)a;//SI
		int ab=a;//SI
		long ac=a;//SI
		float ad=a;//SI
		double ae=a;//SI
		char af=(char)a;//SI
		boolean ag=(boolean)a;//NO
		String ah=(String)a;//NO
		
		
		int b=12;
		byte ba=(byte)b;//SI
		short bb=(short)b;//SI
		long bc=b;//SI
		float bd=b;//SI
		double be=b;//SI
		char bf=(char)b;//SI
		boolean bg=(boolean)b;//NO
		String bh=(String)b;//NO
		
		
		long e=56;
		float ea=e;
		int eb=(int)e;//SI
		byte ec=(byte)e;//SI
		short ed=(short)e;//SI
		double ee=e;//SI
		char ef=(char)e;//SI
		boolean eg=(boolean)e;//NO
		String eh=(String)e;//NO
		
		
		float d=3.38F;
		int da=(int)d;//SI
		byte db=(byte)d;//SI
		short dc=(short)d;//SI
		long dd=(long)d;//SI
		double de=d;//SI
		char df=(char)d;//SI
		boolean dg=(boolean)d;//NO
		String dh=(String)d;//NO
		
	
		
		
		
		
		double g=543;
		byte ga=(byte)g;//SI
		short gb=(short)g;//SI
		int gc=(int)g;//SI
		long gd=(long)g;//SI
		float gf=(float)g;//SI
		char gh=(char)g;//SI
		boolean gj=(boolean)g;//NO
		String gv=(String)g;//NO
		
		
		
		
		
		char w='a';
		byte wa=(byte)w;//SI
		short wb=(short)w;//SI
		int wc=w;//SI
		long wd=w;//SI
		float wf=w;//SI
		double wg=w;//SI
		boolean wh=(boolean)w;//NO
		String wi=(String)w;//NO

		
		
		
		
		boolean h=false;
		byte hb=(byte)h;//NO
		short ha=(short)h;//NO
		int hc=(int)h;//NO
		long he=(long)h;//NO
		float hf=(float)h;//NO
		double hg=(double)h;//NO
		char hd=(char)h;//NO
		String hi=(String)h;//NO

		
		
		
		
		String i="Hola";
		byte ia=(byte)i;//NO
		short ib=(short)i;//NO
		int ic=(int)i;//NO
		long ie=(long)i;//NO
		float if=(float)i;//NO
		double ig=(double)i;//NO
		char id=(char)i;//NO
		boolean ih=(boolean)i;//NO
	

	}
}
