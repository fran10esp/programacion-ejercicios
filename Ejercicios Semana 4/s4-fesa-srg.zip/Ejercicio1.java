
public class Ejercicio1 {

	public static void main(String args []) {
		
		byte myByte = 125;
		System.out.println(myByte);
		short myShort = 32342;
		System.out.println(myShort);
		char myChar = 97;
		System.out.println(myChar);
		float myFloat = 3.0;
		System.out.println(myFloat);
		/*El programa da error de compilaci�n porque al declarar la variable de tipo float y asignarle un valor decima,
		no hemos escrito una "F" al final de la declaraci�n.*/

		
	}
}
