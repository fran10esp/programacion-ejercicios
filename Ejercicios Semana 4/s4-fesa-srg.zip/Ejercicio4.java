
public class Ejercicio4 {
	
	public static void main(String args []) {
			
		int a,b;
		float c=3;
		boolean r,s,t,u,v,w,x;
		a = 3;
		b = 8;
		r = a == 0;
		s = a != 0;
		t = a <= b;
		u = b >= a;
		v = b > a;
		w = b < a;
		x = c == 3.0;
		System.out.println("r:" + r);
		System.out.println("s:" + s);
		System.out.println("t:" + t);
		System.out.println("u:" + u);
		System.out.println("v:" + v);
		System.out.println("w:" + w);
		System.out.println("x:" + x);
		//El programa realiza una serie de comparaciones. Si la comparaci�n se cumple, el programa imprime "true".
		//En caso contrario, imprimir� "false".
		}
}
