
public class Ejercicio6 {
	
	public static void main(String args []) {
		
		//Este tipo de operadores abreviados se utilizan para ahorrar c�digo.
		int a = 4;
		float b = 13.3F;
		boolean c = false;
		a += 2; //a=a+2 //SUMA
		System.out.println(a);
		a -= 3; //a=a-3 //RESTA
		System.out.println(a);
		a *= 3; //a=a*3 //PRODUCTO
		System.out.println(a);
		a /= 2; //a=a/2 //COCIENTE
		System.out.println(a);
		a %= 4; //a=a%4 //M�DULO
		System.out.println(a);
		b /= 2; //b=b/2 //COCIENTE
		System.out.println(b);
		c &= true; //Compara si c es "true"
		System.out.println(c);
		c |= true; //Compara si c es "false"
		System.out.println(c);

	}
}
