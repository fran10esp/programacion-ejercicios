
public class Ejercicio2 {
	
	public static void main(String args []) {
		
		byte c=5;
		short ca=c;//SI
		int cb=c;//SI
		long cc=c;//SI
		float cd=c;//SI
		double ce=c;//SI
		char cf=c;//NO
		boolean cg=c;//NO
		String ch=c;//NO
		
		
		short a=2;
		byte aa=a;//NO
		int ab=a;//SI
		long ac=a;//SI
		float ad=a;//SI
		double ae=a;//SI
		char af=a;//NO
		boolean ag=a;//NO
		String ah=a;//NO
		
		
		int b=12;
		byte ba=b;//NO
		short bb=b;//NO
		long bc=b;//SI
		float bd=b;//SI
		double be=b;//SI
		char bf=b;//NO
		boolean bg=b;//NO
		String bh=b;//NO
		
		
		long e=56;
		float ea=e;
		int eb=e;//NO
		byte ec=e;//NO
		short ed=e;//NO
		double ee=e;//SI
		char ef=e;//NO
		boolean eg=e;//NO
		String eh=e;//NO
		
		
		float d=3.38F;
		int da=d;//NO
		byte db=d;//NO
		short dc=d;//NO
		long dd=d;//NO
		double de=d;//SI
		char df=d;//NO
		boolean dg=d;//NO
		String dh=d;//NO
		
	
		
		
		
		
		double g=543;
		byte ga=g;//NO
		short gb=g;//NO
		int gc=g;//NO
		long gd=g;//NO
		float gf=g;//NO
		char gh=g;//NO
		boolean gj=g;//NO
		String gv=g;//NO
		
		
		
		
		
		char w='a';
		byte wa=w;//NO
		short wb=w;//NO
		int wc=w;//SI
		long wd=w;//SI
		float wf=w;//SI
		double wg=w;//SI
		boolean wh=w;//NO
		String wi=w;//NO

		
		
		
		
		boolean h=false;
		byte hb=h;//NO
		short ha=h;//NO
		int hc=h;//NO
		long he=h;//NO
		float hf=h;//NO
		double hg=h;//NO
		char hd=h;//NO
		String hi=h;//NO

		
		
		
		
		String i="Hola";
		byte ia=i;//NO
		short ib=i;//NO
		int ic=i;//NO
		long ie=i;//NO
		float if=i;//NO
		double ig=i;//NO
		char id=i;//NO
		boolean ih=i;//NO
	

		
	
	}
}
