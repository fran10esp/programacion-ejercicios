
public class Ejercicio7 {

	public static void main(String args []) {
		
		int a=5,b=3;
		boolean r=true,s=false;
		a+=b+8*b;
		r&=s;
		System.out.println("a:" + a);
		System.out.println("b:" + b);
		System.out.println("r:" + r);
		System.out.println("s:" + s);
		/*El programa declara dos variables de tipo entero, realiza una operaci�n con ellas haciendo uso de un operador abreviado
		y luego imprime el resultado por pantalla.
		Tambi�n declara dos variable de tipo boolean y realiza una comparaci�n entre ellas.
		El programa imprime por pantalla el resultado de dicha comparaci�n.*/
	}
}
